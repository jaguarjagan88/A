import React from 'react';
import { ShoppingCart, Heart, Eye } from 'lucide-react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { state, dispatch } = useApp();

  const addToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  const addToWishlist = () => {
    dispatch({ 
      type: 'ADD_TO_WISHLIST', 
      payload: { listId: 'default', product } 
    });
  };

  const viewDetails = () => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `product-${product.id}` });
  };

  return (
    <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} rounded-lg shadow-lg overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-xl`}>
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        {product.safeForKids && (
          <span className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
            Kid Safe
          </span>
        )}
      </div>

      <div className="p-4">
        <h3 className={`font-semibold text-lg mb-2 ${fontColorOptions[state.fontColor]}`}>
          {product.name}
        </h3>
        
        <p className={`text-sm mb-3 opacity-80 ${fontColorOptions[state.fontColor]}`}>
          {product.description}
        </p>

        <div className="mb-3">
          <h4 className={`text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
            Health Benefits:
          </h4>
          <ul className={`text-xs space-y-1 ${fontColorOptions[state.fontColor]} opacity-70`}>
            {product.medicalBenefits.slice(0, 2).map((benefit, index) => (
              <li key={index}>• {benefit}</li>
            ))}
          </ul>
        </div>

        <div className="flex items-center justify-between mb-4">
          <span className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
            ₹{product.price}
          </span>
          <span className={`text-sm ${product.inStock ? 'text-green-500' : 'text-red-500'}`}>
            {product.inStock ? 'In Stock' : 'Out of Stock'}
          </span>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={addToCart}
            disabled={!product.inStock}
            className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-2 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors"
          >
            <ShoppingCart size={16} />
            <span>Add to Cart</span>
          </button>
          
          <button
            onClick={addToWishlist}
            className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Heart size={16} className="text-gray-600" />
          </button>
          
          <button
            onClick={viewDetails}
            className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Eye size={16} className="text-gray-600" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;