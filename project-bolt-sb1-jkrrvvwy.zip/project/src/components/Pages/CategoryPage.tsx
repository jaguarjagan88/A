import React from 'react';
import { products, categories } from '../../data/products';
import ProductCard from '../Product/ProductCard';
import RecommendationPanel from '../Product/RecommendationPanel';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

interface CategoryPageProps {
  categoryId: string;
}

const CategoryPage: React.FC<CategoryPageProps> = ({ categoryId }) => {
  const { state } = useApp();
  const category = categories.find(c => c.id === categoryId);
  const categoryProducts = products.filter(p => p.category === categoryId);

  if (!category) {
    return <div>Category not found</div>;
  }

  return (
    <div className="space-y-8">
      <RecommendationPanel />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className={`text-sm mb-6 ${fontColorOptions[state.fontColor]} opacity-70`}>
          <button
            onClick={() => state.dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
            className="hover:underline"
          >
            Home
          </button>
          <span className="mx-2">{'<<'}</span>
          <span>{category.name}</span>
        </nav>

        {/* Category Header */}
        <div className="flex items-center space-x-4 mb-8">
          <span className="text-5xl">{category.icon}</span>
          <div>
            <h1 className={`text-4xl font-bold mb-2 ${fontColorOptions[state.fontColor]}`}>
              {category.name}
            </h1>
            <p className={`text-lg opacity-80 ${fontColorOptions[state.fontColor]}`}>
              Traditional, healthy products made with care
            </p>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categoryProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {categoryProducts.length === 0 && (
          <div className={`text-center py-12 ${fontColorOptions[state.fontColor]}`}>
            <p className="text-xl">No products available in this category yet.</p>
            <p className="opacity-70">Check back soon for new arrivals!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;