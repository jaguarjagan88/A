import React, { useState } from 'react';
import { CreditCard, Smartphone, CheckCircle, ExternalLink } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Order } from '../../types';
import { fontColorOptions } from '../../utils/themes';

const CheckoutPage: React.FC = () => {
  const { state, dispatch } = useApp();
  const [paymentStep, setPaymentStep] = useState<'details' | 'payment' | 'confirmation'>('details');
  const [paymentId, setPaymentId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const totalAmount = state.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const upiId = 'jaguarjagan88-2@okicici';

  const handleUPIPayment = () => {
    setIsProcessing(true);
    
    // Create UPI payment URL
    const upiUrl = `upi://pay?pa=${upiId}&pn=AJDFoodsnMalts&am=${totalAmount}&cu=INR&tn=Payment for Order`;
    
    // Try to open UPI app
    const link = document.createElement('a');
    link.href = upiUrl;
    link.click();
    
    // Show payment verification dialog
    setTimeout(() => {
      const confirmed = window.confirm(
        `Please complete the payment of ₹${totalAmount} to ${upiId} in your UPI app.\n\nClick OK after completing the payment, or Cancel to try again.`
      );
      
      if (confirmed) {
        // Simulate payment verification
        const newPaymentId = `PAY_${Date.now()}`;
        setPaymentId(newPaymentId);
        setPaymentStep('confirmation');
        
        // Create order
        const order: Order = {
          id: `ORD_${Date.now()}`,
          userId: state.user!.id,
          items: [...state.cart],
          total: totalAmount,
          status: 'confirmed',
          orderDate: new Date(),
          deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
          trackingId: `TRK_${Date.now()}`,
          paymentId: newPaymentId
        };
        
        dispatch({ type: 'ADD_ORDER', payload: order });
        dispatch({ type: 'CLEAR_CART' });
      }
      
      setIsProcessing(false);
    }, 2000);
  };

  const handleManualUPI = () => {
    // Show UPI details for manual payment
    const paymentDetails = `
UPI ID: ${upiId}
Amount: ₹${totalAmount}
Merchant: AJDFoodsnMalts

Please make the payment using any UPI app and enter the transaction ID below.
    `;
    
    const transactionId = prompt(paymentDetails + '\n\nEnter Transaction ID after payment:');
    
    if (transactionId && transactionId.trim()) {
      const newPaymentId = `PAY_${Date.now()}`;
      setPaymentId(newPaymentId);
      setPaymentStep('confirmation');
      
      // Create order
      const order: Order = {
        id: `ORD_${Date.now()}`,
        userId: state.user!.id,
        items: [...state.cart],
        total: totalAmount,
        status: 'confirmed',
        orderDate: new Date(),
        deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        trackingId: `TRK_${Date.now()}`,
        paymentId: newPaymentId
      };
      
      dispatch({ type: 'ADD_ORDER', payload: order });
      dispatch({ type: 'CLEAR_CART' });
    }
  };

  const goToOrders = () => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: 'orders' });
  };

  if (paymentStep === 'confirmation') {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-8 rounded-lg shadow-lg text-center`}>
          <div className="mb-6">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className={`text-2xl font-bold ${fontColorOptions[state.fontColor]}`}>
              Order Confirmed!
            </h2>
            <p className={`${fontColorOptions[state.fontColor]} opacity-70 mt-2`}>
              Payment ID: {paymentId}
            </p>
          </div>

          <div className={`${state.theme === 'light' ? 'bg-gray-50' : 'bg-gray-700'} p-4 rounded-lg mb-6`}>
            <p className={`${fontColorOptions[state.fontColor]}`}>
              Total Amount: <span className="font-bold">₹{totalAmount}</span>
            </p>
            <p className={`${fontColorOptions[state.fontColor]} text-sm opacity-70 mt-1`}>
              Your order will be delivered within 7 business days
            </p>
          </div>

          <button
            onClick={goToOrders}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
          >
            View Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8">
      <h1 className={`text-3xl font-bold mb-8 ${fontColorOptions[state.fontColor]}`}>
        Checkout
      </h1>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Order Summary */}
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg h-fit`}>
          <h3 className={`text-xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
            Order Summary
          </h3>
          
          <div className="space-y-3 mb-4">
            {state.cart.map((item) => (
              <div key={item.product.id} className="flex justify-between">
                <span className={`${fontColorOptions[state.fontColor]} opacity-70`}>
                  {item.product.name} x{item.quantity}
                </span>
                <span className={`${fontColorOptions[state.fontColor]}`}>
                  ₹{item.product.price * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <div className={`border-t ${state.theme === 'light' ? 'border-gray-200' : 'border-gray-600'} pt-4`}>
            <div className="flex justify-between items-center">
              <span className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
                Total: ₹{totalAmount}
              </span>
            </div>
          </div>
        </div>

        {/* Payment */}
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg`}>
          <h3 className={`text-xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
            Payment
          </h3>

          {/* Delivery Address */}
          <div className="mb-6">
            <h4 className={`font-semibold mb-2 ${fontColorOptions[state.fontColor]}`}>
              Delivery Address
            </h4>
            <div className={`${state.theme === 'light' ? 'bg-gray-50' : 'bg-gray-700'} p-3 rounded-lg`}>
              <p className={`${fontColorOptions[state.fontColor]}`}>
                {state.user?.username}
              </p>
              <p className={`${fontColorOptions[state.fontColor]} opacity-70 text-sm`}>
                {state.user?.address.street}
              </p>
              <p className={`${fontColorOptions[state.fontColor]} opacity-70 text-sm`}>
                {state.user?.address.city}, {state.user?.address.state} - {state.user?.address.pincode}
              </p>
              <p className={`${fontColorOptions[state.fontColor]} opacity-70 text-sm`}>
                Phone: {state.user?.phone}
              </p>
            </div>
          </div>

          {/* Payment Method */}
          <div className="mb-6">
            <h4 className={`font-semibold mb-3 ${fontColorOptions[state.fontColor]}`}>
              Payment Method
            </h4>
            <div className={`${state.theme === 'light' ? 'bg-gray-50' : 'bg-gray-700'} p-4 rounded-lg mb-4`}>
              <div className="flex items-center space-x-3 mb-3">
                <Smartphone size={24} className="text-blue-500" />
                <div>
                  <p className={`font-medium ${fontColorOptions[state.fontColor]}`}>
                    UPI Payment
                  </p>
                  <p className={`text-sm opacity-70 ${fontColorOptions[state.fontColor]}`}>
                    Pay using any UPI app
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                  UPI ID: 
                </p>
                <code className={`text-sm ${fontColorOptions[state.fontColor]} bg-blue-100 px-2 py-1 rounded`}>
                  {upiId}
                </code>
              </div>
            </div>
          </div>

          {/* Payment Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleUPIPayment}
              disabled={isProcessing}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <Smartphone size={20} />
              <span>{isProcessing ? 'Processing...' : `Pay ₹${totalAmount} via UPI App`}</span>
              <ExternalLink size={16} />
            </button>

            <button
              onClick={handleManualUPI}
              className="w-full border border-blue-600 text-blue-600 hover:bg-blue-50 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <CreditCard size={20} />
              <span>Manual UPI Payment</span>
            </button>
          </div>

          <div className={`mt-4 p-3 rounded-lg ${state.theme === 'light' ? 'bg-yellow-50 border border-yellow-200' : 'bg-yellow-900 bg-opacity-30'}`}>
            <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-80`}>
              <strong>Note:</strong> After clicking "Pay via UPI App", you'll be redirected to your UPI app. 
              Complete the payment and return here to confirm your order.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;