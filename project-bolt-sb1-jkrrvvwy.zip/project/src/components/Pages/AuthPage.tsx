import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, CheckCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User as UserType } from '../../types';
import { fontColorOptions } from '../../utils/themes';

const AuthPage: React.FC = () => {
  const { state, dispatch } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [emailVerified, setEmailVerified] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [sentCode, setSentCode] = useState('');
  const [showVerification, setShowVerification] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    pincode: '',
    rememberMe: false
  });

  const generateVerificationCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const sendVerificationEmail = () => {
    const code = generateVerificationCode();
    setSentCode(code);
    setShowVerification(true);
    
    // Simulate email sending
    alert(`Verification code sent to ${formData.email}: ${code}`);
  };

  const verifyEmail = () => {
    if (verificationCode === sentCode) {
      setEmailVerified(true);
      setShowVerification(false);
      alert('Email verified successfully!');
    } else {
      alert('Invalid verification code. Please try again.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isLogin && !emailVerified) {
      sendVerificationEmail();
      return;
    }
    
    const user: UserType = {
      id: Date.now().toString(),
      username: formData.username || formData.email.split('@')[0],
      email: formData.email,
      phone: formData.phone,
      address: {
        street: formData.street,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode
      },
      rememberMe: formData.rememberMe
    };

    dispatch({ type: 'SET_USER', payload: user });
    dispatch({ type: 'SET_CURRENT_PAGE', payload: 'cart' });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <div className="max-w-md mx-auto py-12">
      <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-8 rounded-lg shadow-lg`}>
        <h2 className={`text-2xl font-bold text-center mb-6 ${fontColorOptions[state.fontColor]}`}>
          {isLogin ? 'Sign In' : 'Sign Up'}
        </h2>

        {/* Email Verification Modal */}
        {showVerification && (
          <div className={`mb-6 p-4 rounded-lg ${state.theme === 'light' ? 'bg-blue-50 border border-blue-200' : 'bg-blue-900 bg-opacity-50'}`}>
            <h3 className={`font-semibold mb-2 ${fontColorOptions[state.fontColor]}`}>
              Email Verification Required
            </h3>
            <p className={`text-sm mb-4 ${fontColorOptions[state.fontColor]} opacity-80`}>
              We've sent a verification code to {formData.email}
            </p>
            <div className="flex space-x-2">
              <input
                type="text"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                placeholder="Enter 6-digit code"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                maxLength={6}
              />
              <button
                onClick={verifyEmail}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Verify
              </button>
            </div>
          </div>
        )}

        {/* Email Verified Indicator */}
        {emailVerified && (
          <div className={`mb-6 p-3 rounded-lg ${state.theme === 'light' ? 'bg-green-50 border border-green-200' : 'bg-green-900 bg-opacity-50'} flex items-center space-x-2`}>
            <CheckCircle size={20} className="text-green-500" />
            <span className={`text-sm ${fontColorOptions[state.fontColor]}`}>
              Email verified successfully!
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
              <Mail size={16} className="inline mr-2" />
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
              Password
            </label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {!isLogin && (
            <>
              <div>
                <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                  <User size={16} className="inline mr-2" />
                  Username
                </label>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                  <Phone size={16} className="inline mr-2" />
                  Phone
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                  <MapPin size={16} className="inline mr-2" />
                  Street Address
                </label>
                <input
                  type="text"
                  name="street"
                  value={formData.street}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                    City
                  </label>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                    State
                  </label>
                  <input
                    type="text"
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className={`block text-sm font-medium mb-1 ${fontColorOptions[state.fontColor]}`}>
                  PIN Code
                </label>
                <input
                  type="text"
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </>
          )}

          <div className="flex items-center">
            <input
              type="checkbox"
              id="rememberMe"
              name="rememberMe"
              checked={formData.rememberMe}
              onChange={handleInputChange}
              className="mr-2"
            />
            <label htmlFor="rememberMe" className={`text-sm ${fontColorOptions[state.fontColor]}`}>
              Remember me for next visit
            </label>
          </div>

          <button
            type="submit"
            disabled={!isLogin && !emailVerified && !showVerification}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 rounded-lg font-semibold transition-colors"
          >
            {!isLogin && !emailVerified ? 'Send Verification Code' : isLogin ? 'Sign In' : 'Sign Up'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setEmailVerified(false);
              setShowVerification(false);
            }}
            className={`text-blue-500 hover:underline ${fontColorOptions[state.fontColor]}`}
          >
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;