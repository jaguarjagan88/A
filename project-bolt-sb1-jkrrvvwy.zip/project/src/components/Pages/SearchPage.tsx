import React from 'react';
import { Search } from 'lucide-react';
import { products } from '../../data/products';
import ProductCard from '../Product/ProductCard';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

interface SearchPageProps {
  query: string;
}

const SearchPage: React.FC<SearchPageProps> = ({ query }) => {
  const { state } = useApp();

  // Search products with fuzzy matching
  const searchResults = products.filter(product => {
    const searchTerm = query.toLowerCase();
    return (
      product.name.toLowerCase().includes(searchTerm) ||
      product.description.toLowerCase().includes(searchTerm) ||
      product.category.toLowerCase().includes(searchTerm) ||
      product.ingredients.some(ingredient => 
        ingredient.toLowerCase().includes(searchTerm)
      ) ||
      product.medicalBenefits.some(benefit => 
        benefit.toLowerCase().includes(searchTerm)
      )
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <nav className={`text-sm mb-6 ${fontColorOptions[state.fontColor]} opacity-70`}>
        <button
          onClick={() => state.dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
          className="hover:underline"
        >
          Home
        </button>
        <span className="mx-2">{'<<'}</span>
        <span>Search Results</span>
      </nav>

      {/* Search Header */}
      <div className="flex items-center space-x-4 mb-8">
        <Search size={32} className="text-blue-500" />
        <div>
          <h1 className={`text-3xl font-bold ${fontColorOptions[state.fontColor]}`}>
            Search Results
          </h1>
          <p className={`text-lg opacity-80 ${fontColorOptions[state.fontColor]}`}>
            Showing results for "{query}"
          </p>
        </div>
      </div>

      {/* Results Count */}
      <div className={`mb-6 ${fontColorOptions[state.fontColor]} opacity-70`}>
        Found {searchResults.length} product{searchResults.length !== 1 ? 's' : ''}
      </div>

      {/* Search Results */}
      {searchResults.length === 0 ? (
        <div className={`text-center py-12 ${fontColorOptions[state.fontColor]}`}>
          <Search size={64} className="mx-auto mb-4 opacity-50" />
          <h2 className="text-2xl font-bold mb-4">No products found</h2>
          <p className="opacity-70 mb-8">
            Try searching with different keywords or browse our categories
          </p>
          <button
            onClick={() => state.dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Browse Categories
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {searchResults.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default SearchPage;