import React from 'react';
import { ShoppingCart, Heart, ArrowLeft } from 'lucide-react';
import { products } from '../../data/products';
import RecommendationPanel from '../Product/RecommendationPanel';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

interface ProductPageProps {
  productId: string;
}

const ProductPage: React.FC<ProductPageProps> = ({ productId }) => {
  const { state, dispatch } = useApp();
  const product = products.find(p => p.id === productId);

  if (!product) {
    return <div>Product not found</div>;
  }

  const addToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  const addToWishlist = () => {
    dispatch({ 
      type: 'ADD_TO_WISHLIST', 
      payload: { listId: 'default', product } 
    });
  };

  const goBack = () => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `category-${product.category}` });
  };

  return (
    <div className="space-y-8">
      <RecommendationPanel />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className={`text-sm mb-6 ${fontColorOptions[state.fontColor]} opacity-70`}>
          <button
            onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
            className="hover:underline"
          >
            Home
          </button>
          <span className="mx-2">{'<<'}</span>
          <button onClick={goBack} className="hover:underline">
            {product.category.replace('-', ' ')}
          </button>
          <span className="mx-2">{'<<'}</span>
          <span>{product.name}</span>
        </nav>

        {/* Back Button */}
        <button
          onClick={goBack}
          className={`flex items-center space-x-2 mb-6 ${fontColorOptions[state.fontColor]} hover:opacity-80`}
        >
          <ArrowLeft size={20} />
          <span>Back to Category</span>
        </button>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-96 object-cover rounded-lg shadow-lg"
            />
            {product.safeForKids && (
              <span className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full">
                Safe for Kids
              </span>
            )}
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className={`text-4xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
                {product.name}
              </h1>
              <p className={`text-xl mb-4 ${fontColorOptions[state.fontColor]} opacity-80`}>
                {product.description}
              </p>
              <div className="flex items-center justify-between">
                <span className={`text-3xl font-bold ${fontColorOptions[state.fontColor]}`}>
                  ₹{product.price}
                </span>
                <span className={`text-lg ${product.inStock ? 'text-green-500' : 'text-red-500'}`}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
              </div>
            </div>

            {/* Ingredients */}
            <div>
              <h3 className={`text-xl font-semibold mb-3 ${fontColorOptions[state.fontColor]}`}>
                Ingredients
              </h3>
              <div className="flex flex-wrap gap-2">
                {product.ingredients.map((ingredient, index) => (
                  <span
                    key={index}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                  >
                    {ingredient}
                  </span>
                ))}
              </div>
            </div>

            {/* Medical Benefits */}
            <div>
              <h3 className={`text-xl font-semibold mb-3 ${fontColorOptions[state.fontColor]}`}>
                Health Benefits
              </h3>
              <ul className={`space-y-2 ${fontColorOptions[state.fontColor]} opacity-80`}>
                {product.medicalBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <span className="text-green-500 mt-1">•</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructions */}
            <div>
              <h3 className={`text-xl font-semibold mb-3 ${fontColorOptions[state.fontColor]}`}>
                How to Use
              </h3>
              <p className={`${fontColorOptions[state.fontColor]} opacity-80 leading-relaxed`}>
                {product.instructions}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4 pt-6">
              <button
                onClick={addToCart}
                disabled={!product.inStock}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 px-6 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <ShoppingCart size={20} />
                <span>Add to Cart</span>
              </button>
              
              <button
                onClick={addToWishlist}
                className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Heart size={20} className="text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;