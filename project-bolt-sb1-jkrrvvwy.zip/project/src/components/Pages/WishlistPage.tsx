import React, { useState } from 'react';
import { Heart, Plus, Trash2, ShoppingCart } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';
import ProductCard from '../Product/ProductCard';

const WishlistPage: React.FC = () => {
  const { state, dispatch } = useApp();
  const [newListName, setNewListName] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);

  const createNewList = () => {
    if (newListName.trim()) {
      dispatch({ type: 'CREATE_WISHLIST', payload: newListName });
      setNewListName('');
      setShowCreateForm(false);
    }
  };

  const removeFromWishlist = (listId: string, productId: string) => {
    dispatch({ 
      type: 'REMOVE_FROM_WISHLIST', 
      payload: { listId, productId } 
    });
  };

  const addToCart = (product: any) => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className={`text-3xl font-bold ${fontColorOptions[state.fontColor]}`}>
          My Wishlist
        </h1>
        
        <button
          onClick={() => setShowCreateForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus size={20} />
          <span>Create New List</span>
        </button>
      </div>

      {/* Create New List Form */}
      {showCreateForm && (
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg mb-8`}>
          <h3 className={`text-lg font-semibold mb-4 ${fontColorOptions[state.fontColor]}`}>
            Create New Wishlist
          </h3>
          <div className="flex space-x-4">
            <input
              type="text"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              placeholder="Enter list name..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={createNewList}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Create
            </button>
            <button
              onClick={() => setShowCreateForm(false)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Wishlist Items */}
      <div className="space-y-8">
        {state.wishlist.map((list) => (
          <div key={list.id}>
            <div className="flex items-center space-x-4 mb-6">
              <Heart size={24} className="text-red-500" />
              <h2 className={`text-2xl font-bold ${fontColorOptions[state.fontColor]}`}>
                {list.name}
              </h2>
              <span className={`text-sm opacity-70 ${fontColorOptions[state.fontColor]}`}>
                ({list.products.length} items)
              </span>
            </div>

            {list.products.length === 0 ? (
              <div className={`text-center py-12 ${fontColorOptions[state.fontColor]} opacity-70`}>
                <Heart size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg">No items in this wishlist yet</p>
                <p>Add products you love to keep track of them</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {list.products.map((product) => (
                  <div key={product.id} className="relative">
                    <ProductCard product={product} />
                    <div className="absolute top-2 right-2 flex space-x-2">
                      <button
                        onClick={() => addToCart(product)}
                        className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors"
                        title="Add to Cart"
                      >
                        <ShoppingCart size={16} />
                      </button>
                      <button
                        onClick={() => removeFromWishlist(list.id, product.id)}
                        className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors"
                        title="Remove from Wishlist"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WishlistPage;