import React from 'react';
import { Package, Truck, CheckCircle, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

const OrdersPage: React.FC = () => {
  const { state } = useApp();

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="text-yellow-500" size={20} />;
      case 'confirmed':
        return <CheckCircle className="text-blue-500" size={20} />;
      case 'shipped':
        return <Truck className="text-purple-500" size={20} />;
      case 'delivered':
        return <CheckCircle className="text-green-500" size={20} />;
      default:
        return <Package className="text-gray-500" size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'text-yellow-500';
      case 'confirmed':
        return 'text-blue-500';
      case 'shipped':
        return 'text-purple-500';
      case 'delivered':
        return 'text-green-500';
      default:
        return 'text-gray-500';
    }
  };

  if (state.orders.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <Package size={64} className={`mx-auto mb-4 ${fontColorOptions[state.fontColor]} opacity-50`} />
          <h2 className={`text-2xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
            No orders yet
          </h2>
          <p className={`${fontColorOptions[state.fontColor]} opacity-70 mb-8`}>
            Start shopping to see your orders here
          </p>
          <button
            onClick={() => state.dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Start Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className={`text-3xl font-bold mb-8 ${fontColorOptions[state.fontColor]}`}>
        My Orders
      </h1>

      <div className="space-y-6">
        {state.orders.map((order) => (
          <div
            key={order.id}
            className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg`}
          >
            {/* Order Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                {getStatusIcon(order.status)}
                <div>
                  <h3 className={`text-lg font-semibold ${fontColorOptions[state.fontColor]}`}>
                    Order #{order.id.slice(-8)}
                  </h3>
                  <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                    Placed on {order.orderDate.toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-lg font-bold ${fontColorOptions[state.fontColor]}`}>
                  ₹{order.total}
                </p>
                <p className={`text-sm ${getStatusColor(order.status)}`}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </p>
              </div>
            </div>

            {/* Order Items */}
            <div className="mb-4">
              <h4 className={`font-medium mb-2 ${fontColorOptions[state.fontColor]}`}>
                Items ({order.items.length})
              </h4>
              <div className="space-y-2">
                {order.items.map((item, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                    <div className="flex-1">
                      <p className={`font-medium ${fontColorOptions[state.fontColor]}`}>
                        {item.product.name}
                      </p>
                      <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                        Quantity: {item.quantity} • ₹{item.product.price} each
                      </p>
                    </div>
                    <p className={`font-medium ${fontColorOptions[state.fontColor]}`}>
                      ₹{item.product.price * item.quantity}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Tracking Info */}
            <div className={`border-t ${state.theme === 'light' ? 'border-gray-200' : 'border-gray-600'} pt-4`}>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className={`text-sm font-medium ${fontColorOptions[state.fontColor]}`}>
                    Tracking ID
                  </p>
                  <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                    {order.trackingId}
                  </p>
                </div>
                <div>
                  <p className={`text-sm font-medium ${fontColorOptions[state.fontColor]}`}>
                    Expected Delivery
                  </p>
                  <p className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                    {order.deliveryDate?.toLocaleDateString() || 'TBD'}
                  </p>
                </div>
              </div>
            </div>

            {/* Order Actions */}
            <div className="flex space-x-4 mt-4">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                Track Order
              </button>
              {order.status === 'delivered' && (
                <button className="border border-gray-300 hover:bg-gray-50 px-4 py-2 rounded-lg transition-colors">
                  Reorder
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrdersPage;