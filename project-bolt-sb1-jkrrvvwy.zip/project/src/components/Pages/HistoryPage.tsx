import React from 'react';
import { History, Search, Package, Eye } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

const HistoryPage: React.FC = () => {
  const { state, dispatch } = useApp();

  const handleSearchAgain = (query: string) => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `search-${query}` });
  };

  const viewOrder = (orderId: string) => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `order-${orderId}` });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className={`text-3xl font-bold mb-8 ${fontColorOptions[state.fontColor]}`}>
        History
      </h1>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Search History */}
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg`}>
          <div className="flex items-center space-x-3 mb-6">
            <Search size={24} className="text-blue-500" />
            <h2 className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
              Search History
            </h2>
          </div>

          {state.searchHistory.length === 0 ? (
            <div className={`text-center py-8 ${fontColorOptions[state.fontColor]} opacity-70`}>
              <Search size={48} className="mx-auto mb-4 opacity-50" />
              <p>No search history yet</p>
              <p className="text-sm">Your searches will appear here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {state.searchHistory.map((query, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between p-3 rounded-lg ${state.theme === 'light' ? 'bg-gray-50' : 'bg-gray-700'}`}
                >
                  <span className={`${fontColorOptions[state.fontColor]}`}>
                    {query}
                  </span>
                  <button
                    onClick={() => handleSearchAgain(query)}
                    className="text-blue-500 hover:text-blue-600 transition-colors"
                  >
                    <Search size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order History */}
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg`}>
          <div className="flex items-center space-x-3 mb-6">
            <Package size={24} className="text-green-500" />
            <h2 className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
              Order History
            </h2>
          </div>

          {state.orders.length === 0 ? (
            <div className={`text-center py-8 ${fontColorOptions[state.fontColor]} opacity-70`}>
              <Package size={48} className="mx-auto mb-4 opacity-50" />
              <p>No orders yet</p>
              <p className="text-sm">Your order history will appear here</p>
            </div>
          ) : (
            <div className="space-y-4">
              {state.orders.slice(0, 5).map((order) => (
                <div
                  key={order.id}
                  className={`p-4 rounded-lg border ${state.theme === 'light' ? 'border-gray-200 bg-gray-50' : 'border-gray-600 bg-gray-700'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`font-semibold ${fontColorOptions[state.fontColor]}`}>
                      Order #{order.id.slice(-6)}
                    </span>
                    <span className={`text-sm ${
                      order.status === 'delivered' ? 'text-green-500' :
                      order.status === 'shipped' ? 'text-blue-500' :
                      order.status === 'confirmed' ? 'text-yellow-500' :
                      'text-gray-500'
                    }`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                  
                  <div className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70 mb-2`}>
                    {order.orderDate.toLocaleDateString()} • ₹{order.total}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className={`text-sm ${fontColorOptions[state.fontColor]} opacity-70`}>
                      {order.items.length} item(s)
                    </span>
                    <button
                      onClick={() => viewOrder(order.id)}
                      className="text-blue-500 hover:text-blue-600 transition-colors"
                    >
                      <Eye size={16} />
                    </button>
                  </div>
                </div>
              ))}
              
              {state.orders.length > 5 && (
                <button
                  onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'orders' })}
                  className="w-full text-center text-blue-500 hover:text-blue-600 transition-colors py-2"
                >
                  View All Orders
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HistoryPage;