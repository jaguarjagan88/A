import React from 'react';
import { Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';

const CartPage: React.FC = () => {
  const { state, dispatch } = useApp();

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
    } else {
      dispatch({ 
        type: 'UPDATE_CART_QUANTITY', 
        payload: { id: productId, quantity: newQuantity } 
      });
    }
  };

  const removeItem = (productId: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
  };

  const getTotalPrice = () => {
    return state.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const proceedToCheckout = () => {
    if (!state.user) {
      dispatch({ type: 'SET_CURRENT_PAGE', payload: 'login' });
    } else {
      dispatch({ type: 'SET_CURRENT_PAGE', payload: 'checkout' });
    }
  };

  if (state.cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <ShoppingBag size={64} className={`mx-auto mb-4 ${fontColorOptions[state.fontColor]} opacity-50`} />
          <h2 className={`text-2xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
            Your cart is empty
          </h2>
          <p className={`${fontColorOptions[state.fontColor]} opacity-70 mb-8`}>
            Discover our traditional and healthy products
          </p>
          <button
            onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className={`text-3xl font-bold mb-8 ${fontColorOptions[state.fontColor]}`}>
        Shopping Cart
      </h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {state.cart.map((item) => (
            <div
              key={item.product.id}
              className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg`}
            >
              <div className="flex items-center space-x-4">
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                
                <div className="flex-1">
                  <h3 className={`font-semibold text-lg ${fontColorOptions[state.fontColor]}`}>
                    {item.product.name}
                  </h3>
                  <p className={`${fontColorOptions[state.fontColor]} opacity-70 text-sm`}>
                    {item.product.description}
                  </p>
                  <p className={`font-bold ${fontColorOptions[state.fontColor]} mt-2`}>
                    ₹{item.product.price}
                  </p>
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                    className="p-1 rounded-full hover:bg-gray-200 transition-colors"
                  >
                    <Minus size={16} />
                  </button>
                  
                  <span className={`font-semibold ${fontColorOptions[state.fontColor]} px-3`}>
                    {item.quantity}
                  </span>
                  
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                    className="p-1 rounded-full hover:bg-gray-200 transition-colors"
                  >
                    <Plus size={16} />
                  </button>
                </div>

                <button
                  onClick={() => removeItem(item.product.id)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-white'} p-6 rounded-lg shadow-lg h-fit`}>
          <h3 className={`text-xl font-bold mb-4 ${fontColorOptions[state.fontColor]}`}>
            Order Summary
          </h3>
          
          <div className="space-y-3 mb-4">
            {state.cart.map((item) => (
              <div key={item.product.id} className="flex justify-between">
                <span className={`${fontColorOptions[state.fontColor]} opacity-70`}>
                  {item.product.name} x{item.quantity}
                </span>
                <span className={`${fontColorOptions[state.fontColor]}`}>
                  ₹{item.product.price * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <div className={`border-t ${state.theme === 'light' ? 'border-gray-200' : 'border-gray-600'} pt-4 mb-6`}>
            <div className="flex justify-between items-center">
              <span className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
                Total: ₹{getTotalPrice()}
              </span>
            </div>
          </div>

          <button
            onClick={proceedToCheckout}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors"
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartPage;