import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { categories } from '../../data/products';
import { useApp } from '../../context/AppContext';

const Navigation: React.FC = () => {
  const { state, dispatch } = useApp();
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const handleCategoryClick = (categoryId: string) => {
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `category-${categoryId}` });
  };

  return (
    <div className={`${state.theme === 'dark' ? 'bg-gray-800' : state.theme === 'peacock' ? 'bg-teal-800' : state.theme === 'neonBlue' ? 'bg-slate-800' : 'bg-gray-100'} py-4`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative flex items-center">
          <button
            onClick={() => scroll('left')}
            className="absolute left-0 z-10 p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>

          <div
            ref={scrollRef}
            className="flex space-x-6 overflow-x-auto scrollbar-hide mx-12"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleCategoryClick(category.id)}
                className="flex flex-col items-center min-w-[80px] p-3 rounded-lg transition-all duration-200 hover:scale-110 hover:bg-white hover:bg-opacity-10"
              >
                <div className="text-3xl mb-2">{category.icon}</div>
                <span className={`text-sm font-medium text-center ${state.theme === 'light' ? 'text-gray-700' : 'text-white'}`}>
                  {category.name}
                </span>
              </button>
            ))}
          </div>

          <button
            onClick={() => scroll('right')}
            className="absolute right-0 z-10 p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Navigation;