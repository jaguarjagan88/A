import React from 'react';
import { X, Heart, Package, User, History, Phone, Settings, Palette, Type } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { categories } from '../../data/products';
import { themes, colorOptions, fontColorOptions } from '../../utils/themes';
import { ColorOption } from '../../types';

const Sidebar: React.FC = () => {
  const { state, dispatch } = useApp();

  if (!state.isMenuOpen) return null;

  const handleThemeChange = (theme: string) => {
    dispatch({ type: 'SET_THEME', payload: theme });
  };

  const handleColorChange = (color: ColorOption) => {
    dispatch({ type: 'SET_CUSTOM_COLOR', payload: color });
  };

  const handleFontColorChange = (color: ColorOption) => {
    dispatch({ type: 'SET_FONT_COLOR', payload: color });
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40"
        onClick={() => dispatch({ type: 'TOGGLE_MENU' })}
      />
      
      <div className={`fixed left-0 top-0 h-full w-80 ${state.theme === 'dark' ? 'bg-gray-900' : state.theme === 'peacock' ? 'bg-teal-900' : state.theme === 'neonBlue' ? 'bg-slate-900' : 'bg-white'} z-50 overflow-y-auto shadow-xl`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className={`text-xl font-bold ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>Menu</h2>
            <button
              onClick={() => dispatch({ type: 'TOGGLE_MENU' })}
              className={`p-2 rounded-lg hover:bg-opacity-80 ${state.theme === 'light' ? 'text-gray-600 hover:bg-gray-100' : 'text-white hover:bg-gray-700'}`}
            >
              <X size={24} />
            </button>
          </div>

          {/* Categories */}
          <div className="mb-8">
            <h3 className={`text-lg font-semibold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>Categories</h3>
            <div className="space-y-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    dispatch({ type: 'SET_CURRENT_PAGE', payload: `category-${category.id}` });
                    dispatch({ type: 'TOGGLE_MENU' });
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
                >
                  <span className="text-xl">{category.icon}</span>
                  <span>{category.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Menu Items */}
          <div className="mb-8">
            <h3 className={`text-lg font-semibold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>Menu</h3>
            <div className="space-y-2">
              <button
                onClick={() => {
                  dispatch({ type: 'SET_CURRENT_PAGE', payload: 'wishlist' });
                  dispatch({ type: 'TOGGLE_MENU' });
                }}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
              >
                <Heart size={20} />
                <span>Wishlist</span>
              </button>
              
              <button
                onClick={() => {
                  dispatch({ type: 'SET_CURRENT_PAGE', payload: 'orders' });
                  dispatch({ type: 'TOGGLE_MENU' });
                }}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
              >
                <Package size={20} />
                <span>View Orders</span>
              </button>

              <button
                onClick={() => {
                  dispatch({ type: 'SET_CURRENT_PAGE', payload: 'profile' });
                  dispatch({ type: 'TOGGLE_MENU' });
                }}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
              >
                <User size={20} />
                <span>User Info</span>
              </button>

              <button
                onClick={() => {
                  dispatch({ type: 'SET_CURRENT_PAGE', payload: 'history' });
                  dispatch({ type: 'TOGGLE_MENU' });
                }}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
              >
                <History size={20} />
                <span>History</span>
              </button>

              <a
                href="mailto:ajdfoods@gmail.com"
                className={`w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-opacity-80 transition-colors ${state.theme === 'light' ? 'hover:bg-gray-100 text-gray-700' : 'hover:bg-gray-700 text-white'}`}
              >
                <Phone size={20} />
                <span>Customer Care</span>
              </a>
            </div>
          </div>

          {/* Theme Settings */}
          <div className="mb-6">
            <h3 className={`text-lg font-semibold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>Theme Settings</h3>
            
            {/* Theme Selection */}
            <div className="mb-4">
              <h4 className={`text-sm font-medium mb-2 ${state.theme === 'light' ? 'text-gray-700' : 'text-gray-300'}`}>Theme</h4>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(themes).map(([key, theme]) => (
                  <button
                    key={key}
                    onClick={() => handleThemeChange(key)}
                    className={`p-2 rounded text-sm transition-colors ${
                      state.theme === key 
                        ? `${colorOptions[state.customColor]} text-white` 
                        : state.theme === 'light' 
                          ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' 
                          : 'bg-gray-700 text-white hover:bg-gray-600'
                    }`}
                  >
                    {theme.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Selection */}
            <div className="mb-4">
              <h4 className={`text-sm font-medium mb-2 ${state.theme === 'light' ? 'text-gray-700' : 'text-gray-300'}`}>
                <Palette size={16} className="inline mr-1" />
                Accent Color
              </h4>
              <div className="grid grid-cols-5 gap-2">
                {Object.entries(colorOptions).map(([key, colorClass]) => (
                  <button
                    key={key}
                    onClick={() => handleColorChange(key as ColorOption)}
                    className={`w-8 h-8 rounded-full ${colorClass} border-2 transition-all ${
                      state.customColor === key 
                        ? 'ring-2 ring-white ring-offset-2 scale-110' 
                        : 'border-gray-300 hover:scale-105'
                    }`}
                    title={key}
                  />
                ))}
              </div>
            </div>

            {/* Font Color Selection */}
            <div>
              <h4 className={`text-sm font-medium mb-2 ${state.theme === 'light' ? 'text-gray-700' : 'text-gray-300'}`}>
                <Type size={16} className="inline mr-1" />
                Font Color
              </h4>
              <div className="grid grid-cols-5 gap-2">
                {Object.entries(colorOptions).map(([key, colorClass]) => (
                  <button
                    key={key}
                    onClick={() => handleFontColorChange(key as ColorOption)}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      key === 'white' 
                        ? 'bg-white border-gray-300' 
                        : key === 'black' 
                          ? 'bg-black border-gray-600' 
                          : `${colorClass} border-gray-300`
                    } ${
                      state.fontColor === key 
                        ? 'ring-2 ring-blue-500 ring-offset-2 scale-110' 
                        : 'hover:scale-105'
                    }`}
                    title={key}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;