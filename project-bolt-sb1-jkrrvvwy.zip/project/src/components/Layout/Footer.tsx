import React from 'react';
import { useApp } from '../../context/AppContext';

const Footer: React.FC = () => {
  const { state, dispatch } = useApp();

  return (
    <footer className={`${state.theme === 'dark' ? 'bg-gray-900' : state.theme === 'peacock' ? 'bg-teal-900' : state.theme === 'neonBlue' ? 'bg-slate-900' : 'bg-gray-100'} py-12 mt-16`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <h3 className={`text-lg font-bold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>
              AJDFoodsnMalts
            </h3>
            <p className={`${state.theme === 'light' ? 'text-gray-600' : 'text-gray-300'} mb-2`}>
              A hygiene certified company
            </p>
            <p className={`${state.theme === 'light' ? 'text-gray-600' : 'text-gray-300'} mb-2`}>
              Traditionally made recipe since 2021
            </p>
            <p className={`${state.theme === 'light' ? 'text-gray-600' : 'text-gray-300'}`}>
              Safe to eat
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className={`text-lg font-semibold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>
              Contact Us
            </h4>
            <div className={`space-y-2 ${state.theme === 'light' ? 'text-gray-600' : 'text-gray-300'}`}>
              <p>Phone: 9360638053</p>
              <p>Email: ajdfoods@gmail.com</p>
            </div>
          </div>

          {/* Legal */}
          <div>
            <h4 className={`text-lg font-semibold mb-4 ${state.theme === 'light' ? 'text-gray-900' : 'text-white'}`}>
              Legal
            </h4>
            <div className="space-y-2">
              <button
                onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'terms' })}
                className={`block ${state.theme === 'light' ? 'text-gray-600 hover:text-gray-900' : 'text-gray-300 hover:text-white'} hover:underline`}
              >
                Terms and Conditions
              </button>
              <button
                onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'privacy' })}
                className={`block ${state.theme === 'light' ? 'text-gray-600 hover:text-gray-900' : 'text-gray-300 hover:text-white'} hover:underline`}
              >
                Privacy Policy
              </button>
            </div>
          </div>
        </div>

        <div className={`border-t ${state.theme === 'light' ? 'border-gray-200' : 'border-gray-700'} mt-8 pt-8 text-center`}>
          <p className={`${state.theme === 'light' ? 'text-gray-600' : 'text-gray-300'}`}>
            © 2025 AJDFoodsnMalts. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;