import React, { useState } from 'react';
import { Home, User, ShoppingCart, Search, Menu, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { fontColorOptions } from '../../utils/themes';
import { products } from '../../data/products';

const Header: React.FC = () => {
  const { state, dispatch } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchSuggestions, setSearchSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    if (query.trim()) {
      // Generate suggestions based on product names with spell tolerance
      const suggestions = products
        .filter(product => 
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.category.toLowerCase().includes(query.toLowerCase()) ||
          product.description.toLowerCase().includes(query.toLowerCase())
        )
        .map(product => product.name)
        .slice(0, 5);
      
      setSearchSuggestions(suggestions);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      dispatch({ type: 'ADD_SEARCH_HISTORY', payload: searchQuery });
      dispatch({ type: 'SET_CURRENT_PAGE', payload: `search-${searchQuery}` });
      setShowSuggestions(false);
      setIsSearchExpanded(false);
      setSearchQuery('');
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    dispatch({ type: 'ADD_SEARCH_HISTORY', payload: suggestion });
    dispatch({ type: 'SET_CURRENT_PAGE', payload: `search-${suggestion}` });
    setShowSuggestions(false);
    setIsSearchExpanded(false);
    setSearchQuery('');
  };

  const toggleSearch = () => {
    setIsSearchExpanded(!isSearchExpanded);
    if (isSearchExpanded) {
      setSearchQuery('');
      setShowSuggestions(false);
    }
  };

  const cartItemCount = state.cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className={`${state.theme === 'dark' ? 'bg-gray-900' : state.theme === 'peacock' ? 'bg-teal-900' : state.theme === 'neonBlue' ? 'bg-slate-900' : 'bg-white'} shadow-lg sticky top-0 z-50`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Company Name */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => dispatch({ type: 'TOGGLE_MENU' })}
              className={`p-2 rounded-lg hover:bg-opacity-80 transition-colors ${fontColorOptions[state.fontColor]}`}
            >
              <Menu size={24} />
            </button>
            
            <div className="flex flex-col">
              <h1 className={`text-xl font-bold ${fontColorOptions[state.fontColor]}`}>
                AJDFoodsnMalts
              </h1>
              <p className={`text-sm opacity-80 ${fontColorOptions[state.fontColor]}`}>
                Homey goods with care
              </p>
            </div>
          </div>

          {/* Expandable Search */}
          <div className="flex-1 flex justify-center">
            <div className="relative">
              {/* Search Icon */}
              {!isSearchExpanded && (
                <button
                  onClick={toggleSearch}
                  className={`p-2 rounded-lg hover:bg-opacity-80 transition-all duration-300 ${fontColorOptions[state.fontColor]}`}
                >
                  <Search size={24} />
                </button>
              )}

              {/* Expanded Search Bar */}
              {isSearchExpanded && (
                <div className="flex items-center space-x-2 animate-in slide-in-from-right duration-300">
                  <form onSubmit={handleSearch} className="relative">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={handleSearchChange}
                      onFocus={() => searchQuery && setShowSuggestions(true)}
                      onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                      placeholder="Search products..."
                      className="w-80 px-4 py-2 pl-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      autoFocus
                    />
                    <button type="submit" className="absolute left-3 top-2.5 text-gray-400 hover:text-gray-600">
                      <Search size={20} />
                    </button>
                    
                    {/* Search Suggestions */}
                    {showSuggestions && searchSuggestions.length > 0 && (
                      <div className="absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-lg shadow-lg mt-1 z-50">
                        {searchSuggestions.map((suggestion, index) => (
                          <button
                            key={index}
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="w-full text-left px-4 py-2 hover:bg-gray-100 first:rounded-t-lg last:rounded-b-lg"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}
                  </form>
                  
                  <button
                    onClick={toggleSearch}
                    className={`p-2 rounded-lg hover:bg-opacity-80 transition-colors ${fontColorOptions[state.fontColor]}`}
                  >
                    <X size={20} />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Icons */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'home' })}
              className={`p-2 rounded-lg hover:bg-opacity-80 transition-colors ${fontColorOptions[state.fontColor]}`}
            >
              <Home size={24} />
            </button>

            <div className="relative">
              <button
                onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: 'cart' })}
                className={`p-2 rounded-lg hover:bg-opacity-80 transition-colors ${fontColorOptions[state.fontColor]}`}
              >
                <ShoppingCart size={24} />
              </button>
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </div>

            <button
              onClick={() => dispatch({ type: 'SET_CURRENT_PAGE', payload: state.user ? 'profile' : 'login' })}
              className={`p-2 rounded-lg hover:bg-opacity-80 transition-colors ${fontColorOptions[state.fontColor]}`}
            >
              <User size={24} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;