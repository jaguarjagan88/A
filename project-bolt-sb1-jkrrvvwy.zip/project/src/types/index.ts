export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
  ingredients: string[];
  medicalBenefits: string[];
  instructions: string;
  safeForKids: boolean;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface WishlistItem {
  id: string;
  name: string;
  products: Product[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  profileImage?: string;
  rememberMe: boolean;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered';
  orderDate: Date;
  deliveryDate?: Date;
  trackingId: string;
  paymentId: string;
}

export interface Theme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
  };
}

export type ColorOption = 'yellow' | 'green' | 'pink' | 'red' | 'orange' | 'blue' | 'lightblue' | 'white' | 'black' | 'purple';