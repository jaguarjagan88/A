import { ColorOption } from '../types';

export const themes = {
  dark: {
    name: 'Dark Theme',
    colors: {
      primary: 'bg-gray-900',
      secondary: 'bg-gray-800',
      accent: 'bg-blue-600',
      background: 'bg-black',
      surface: 'bg-gray-700',
      text: 'text-white'
    }
  },
  light: {
    name: 'Light Theme',
    colors: {
      primary: 'bg-white',
      secondary: 'bg-gray-100',
      accent: 'bg-blue-500',
      background: 'bg-gray-50',
      surface: 'bg-white',
      text: 'text-gray-900'
    }
  },
  peacock: {
    name: 'Peacock Theme',
    colors: {
      primary: 'bg-teal-900',
      secondary: 'bg-teal-800',
      accent: 'bg-emerald-500',
      background: 'bg-slate-900',
      surface: 'bg-teal-700',
      text: 'text-teal-100'
    }
  },
  neonBlue: {
    name: 'Neon Blue Circuit',
    colors: {
      primary: 'bg-slate-900',
      secondary: 'bg-slate-800',
      accent: 'bg-cyan-400',
      background: 'bg-black',
      surface: 'bg-slate-700',
      text: 'text-cyan-100'
    }
  }
};

export const colorOptions: { [key in ColorOption]: string } = {
  yellow: 'bg-yellow-500',
  green: 'bg-green-500',
  pink: 'bg-pink-500',
  red: 'bg-red-500',
  orange: 'bg-orange-500',
  blue: 'bg-blue-500',
  lightblue: 'bg-sky-500',
  white: 'bg-white',
  black: 'bg-black',
  purple: 'bg-purple-500'
};

export const fontColorOptions: { [key in ColorOption]: string } = {
  yellow: 'text-yellow-500',
  green: 'text-green-500',
  pink: 'text-pink-500',
  red: 'text-red-500',
  orange: 'text-orange-500',
  blue: 'text-blue-500',
  lightblue: 'text-sky-500',
  white: 'text-white',
  black: 'text-black',
  purple: 'text-purple-500'
};

export const getThemeClasses = (theme: string, customColor: ColorOption) => {
  const baseTheme = themes[theme as keyof typeof themes] || themes.dark;
  return {
    ...baseTheme.colors,
    accent: colorOptions[customColor] || baseTheme.colors.accent
  };
};

export const circuitPattern = `
  background-image: 
    linear-gradient(90deg, transparent 98%, rgba(0, 255, 255, 0.2) 100%),
    linear-gradient(180deg, transparent 98%, rgba(0, 255, 255, 0.2) 100%);
  background-size: 50px 50px;
`;