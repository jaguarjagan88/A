import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Product, CartItem, WishlistItem, User, Order, Theme, ColorOption } from '../types';

interface AppState {
  theme: string;
  customColor: ColorOption;
  fontColor: ColorOption;
  cart: CartItem[];
  wishlist: WishlistItem[];
  user: User | null;
  orders: Order[];
  searchHistory: string[];
  currentPage: string;
  isMenuOpen: boolean;
}

type AppAction =
  | { type: 'SET_THEME'; payload: string }
  | { type: 'SET_CUSTOM_COLOR'; payload: ColorOption }
  | { type: 'SET_FONT_COLOR'; payload: ColorOption }
  | { type: 'ADD_TO_CART'; payload: Product }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'UPDATE_CART_QUANTITY'; payload: { id: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'ADD_TO_WISHLIST'; payload: { listId: string; product: Product } }
  | { type: 'REMOVE_FROM_WISHLIST'; payload: { listId: string; productId: string } }
  | { type: 'CREATE_WISHLIST'; payload: string }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'ADD_SEARCH_HISTORY'; payload: string }
  | { type: 'SET_CURRENT_PAGE'; payload: string }
  | { type: 'TOGGLE_MENU' };

const initialState: AppState = {
  theme: 'dark',
  customColor: 'blue',
  fontColor: 'white',
  cart: [],
  wishlist: [
    { id: 'default', name: 'My Wishlist', products: [] }
  ],
  user: null,
  orders: [],
  searchHistory: [],
  currentPage: 'home',
  isMenuOpen: false
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_THEME':
      return { ...state, theme: action.payload };
    case 'SET_CUSTOM_COLOR':
      return { ...state, customColor: action.payload };
    case 'SET_FONT_COLOR':
      return { ...state, fontColor: action.payload };
    case 'ADD_TO_CART':
      const existingItem = state.cart.find(item => item.product.id === action.payload.id);
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item.product.id === action.payload.id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          )
        };
      }
      return {
        ...state,
        cart: [...state.cart, { product: action.payload, quantity: 1 }]
      };
    case 'REMOVE_FROM_CART':
      return {
        ...state,
        cart: state.cart.filter(item => item.product.id !== action.payload)
      };
    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.product.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        )
      };
    case 'CLEAR_CART':
      return { ...state, cart: [] };
    case 'ADD_TO_WISHLIST':
      return {
        ...state,
        wishlist: state.wishlist.map(list =>
          list.id === action.payload.listId
            ? { ...list, products: [...list.products, action.payload.product] }
            : list
        )
      };
    case 'REMOVE_FROM_WISHLIST':
      return {
        ...state,
        wishlist: state.wishlist.map(list =>
          list.id === action.payload.listId
            ? { ...list, products: list.products.filter(p => p.id !== action.payload.productId) }
            : list
        )
      };
    case 'CREATE_WISHLIST':
      return {
        ...state,
        wishlist: [...state.wishlist, { id: Date.now().toString(), name: action.payload, products: [] }]
      };
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [...state.orders, action.payload] };
    case 'ADD_SEARCH_HISTORY':
      return {
        ...state,
        searchHistory: [action.payload, ...state.searchHistory.filter(item => item !== action.payload)].slice(0, 10)
      };
    case 'SET_CURRENT_PAGE':
      return { ...state, currentPage: action.payload };
    case 'TOGGLE_MENU':
      return { ...state, isMenuOpen: !state.isMenuOpen };
    default:
      return state;
  }
}

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};