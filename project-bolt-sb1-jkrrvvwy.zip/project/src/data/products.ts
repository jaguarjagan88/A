import { Product } from '../types';

export const categories = [
  { id: 'soup-powder', name: 'Soup Powder', icon: '🍲' },
  { id: 'millet-mix', name: 'Millet Mix', icon: '🌾' },
  { id: 'health-mix', name: 'Health Mix', icon: '💪' },
  { id: 'sweets', name: 'Sweets', icon: '🍯' },
  { id: 'pickle', name: 'Pickle', icon: '🥒' },
  { id: 'congee', name: 'Congee', icon: '🍜' },
  { id: 'spice-mix', name: 'Spice Mix', icon: '🌶️' },
  { id: 'fruit-blend', name: 'Fruit Blend', icon: '🥛' }
];

export const products: Product[] = [
  // Soup Powder
  {
    id: 'sp1',
    name: 'Traditional Tomato Soup Powder',
    category: 'soup-powder',
    price: 120,
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    description: 'Traditionally made tomato soup powder with natural ingredients',
    ingredients: ['Tomatoes', 'Turmeric', 'Ginger', 'Garlic', 'Black pepper'],
    medicalBenefits: ['Rich in Vitamin C', 'Boosts immunity', 'Anti-inflammatory properties'],
    instructions: 'Mix 2 spoons with hot water. Stir well and serve hot.',
    safeForKids: true,
    inStock: true
  },
  {
    id: 'sp2',
    name: 'Spinach & Lentil Soup Mix',
    category: 'soup-powder',
    price: 150,
    image: 'https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg',
    description: 'Nutritious spinach and lentil soup powder for healthy meals',
    ingredients: ['Spinach', 'Moong dal', 'Cumin', 'Coriander', 'Rock salt'],
    medicalBenefits: ['High in iron', 'Protein rich', 'Digestive health'],
    instructions: 'Boil with water for 5 minutes. Add ghee before serving.',
    safeForKids: true,
    inStock: true
  },
  
  // Millet Mix
  {
    id: 'mm1',
    name: 'Multi-Millet Health Powder',
    category: 'millet-mix',
    price: 200,
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg',
    description: 'Blend of 5 different millets for complete nutrition',
    ingredients: ['Foxtail millet', 'Pearl millet', 'Finger millet', 'Little millet', 'Barnyard millet'],
    medicalBenefits: ['Gluten-free', 'Controls diabetes', 'Weight management', 'Heart healthy'],
    instructions: 'Mix with milk or water. Can be made as porridge or smoothie.',
    safeForKids: true,
    inStock: true
  },
  {
    id: 'mm2',
    name: 'Ragi Millet Energy Mix',
    category: 'millet-mix',
    price: 180,
    image: 'https://images.pexels.com/photos/1559188/pexels-photo-1559188.jpeg',
    description: 'Calcium-rich ragi millet mix for bone health',
    ingredients: ['Finger millet', 'Almonds', 'Dates', 'Cardamom'],
    medicalBenefits: ['High calcium', 'Bone strength', 'Natural energy booster'],
    instructions: 'Mix 3 spoons with warm milk. Sweeten with jaggery if needed.',
    safeForKids: true,
    inStock: true
  },

  // Health Mix
  {
    id: 'hm1',
    name: 'Complete Nutrition Health Mix',
    category: 'health-mix',
    price: 250,
    image: 'https://images.pexels.com/photos/1435740/pexels-photo-1435740.jpeg',
    description: 'All-in-one health mix with grains, nuts, and seeds',
    ingredients: ['Wheat', 'Rice', 'Almonds', 'Cashews', 'Sesame seeds', 'Flax seeds'],
    medicalBenefits: ['Complete protein', 'Omega-3 fatty acids', 'Fiber rich', 'Antioxidants'],
    instructions: 'Mix with milk or buttermilk. Can be consumed as breakfast.',
    safeForKids: true,
    inStock: true
  },

  // Sweets
  {
    id: 'sw1',
    name: 'Jaggery Sesame Laddu Mix',
    category: 'sweets',
    price: 180,
    image: 'https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg',
    description: 'Traditional sesame laddu mix sweetened with pure jaggery',
    ingredients: ['Sesame seeds', 'Jaggery', 'Ghee', 'Cardamom'],
    medicalBenefits: ['Natural calcium', 'Healthy fats', 'Iron rich', 'Natural sweetener'],
    instructions: 'Add ghee and form into balls. Ready to eat healthy sweet.',
    safeForKids: true,
    inStock: true
  },

  // Pickle
  {
    id: 'pk1',
    name: 'Homemade Mango Pickle Powder',
    category: 'pickle',
    price: 160,
    image: 'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg',
    description: 'Tangy mango pickle powder made with traditional recipe',
    ingredients: ['Raw mango', 'Red chili', 'Turmeric', 'Fenugreek', 'Mustard seeds'],
    medicalBenefits: ['Digestive aid', 'Vitamin C', 'Probiotics', 'Metabolism booster'],
    instructions: 'Mix with rice or chapati. Store in dry place.',
    safeForKids: false,
    inStock: true
  },

  // Congee
  {
    id: 'cg1',
    name: 'Healing Rice Congee Mix',
    category: 'congee',
    price: 140,
    image: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg',
    description: 'Therapeutic rice congee for easy digestion',
    ingredients: ['Basmati rice', 'Moong dal', 'Cumin', 'Ginger', 'Turmeric'],
    medicalBenefits: ['Easy digestion', 'Recovery food', 'Hydrating', 'Gentle on stomach'],
    instructions: 'Boil with 4 cups water until soft. Add salt to taste.',
    safeForKids: true,
    inStock: true
  },

  // Spice Mix
  {
    id: 'sm1',
    name: 'Garam Masala Blend',
    category: 'spice-mix',
    price: 100,
    image: 'https://images.pexels.com/photos/1435748/pexels-photo-1435748.jpeg',
    description: 'Aromatic garam masala blend for authentic Indian flavors',
    ingredients: ['Cinnamon', 'Cardamom', 'Cloves', 'Black pepper', 'Cumin', 'Coriander'],
    medicalBenefits: ['Anti-inflammatory', 'Digestive properties', 'Antioxidants', 'Metabolism boost'],
    instructions: 'Add to curries in final stages. Use sparingly for best flavor.',
    safeForKids: false,
    inStock: true
  },

  // Fruit Blend
  {
    id: 'fb1',
    name: 'Banana Date Powder',
    category: 'fruit-blend',
    price: 220,
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg',
    description: 'Natural fruit blend powder for milk-based drinks',
    ingredients: ['Dried banana', 'Dates', 'Almonds', 'Cardamom'],
    medicalBenefits: ['Natural energy', 'Potassium rich', 'Fiber content', 'Natural sweetness'],
    instructions: 'Mix 2-3 spoons with warm milk. Stir well and enjoy.',
    safeForKids: true,
    inStock: true
  }
];