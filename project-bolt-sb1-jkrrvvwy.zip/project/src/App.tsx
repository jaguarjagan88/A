import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Header from './components/Layout/Header';
import Navigation from './components/Layout/Navigation';
import Sidebar from './components/Layout/Sidebar';
import Footer from './components/Layout/Footer';
import HomePage from './components/Pages/HomePage';
import CategoryPage from './components/Pages/CategoryPage';
import ProductPage from './components/Pages/ProductPage';
import CartPage from './components/Pages/CartPage';
import AuthPage from './components/Pages/AuthPage';
import CheckoutPage from './components/Pages/CheckoutPage';
import WishlistPage from './components/Pages/WishlistPage';
import HistoryPage from './components/Pages/HistoryPage';
import SearchPage from './components/Pages/SearchPage';
import OrdersPage from './components/Pages/OrdersPage';
import { themes, circuitPattern, colorOptions } from './utils/themes';

const AppContent: React.FC = () => {
  const { state } = useApp();

  const getBackgroundStyle = () => {
    const baseStyle = {
      minHeight: '100vh',
      transition: 'all 0.3s ease'
    };

    if (state.theme === 'neonBlue') {
      return {
        ...baseStyle,
        background: `linear-gradient(135deg, #0f172a 0%, #1e293b 100%)`,
        backgroundImage: circuitPattern
      };
    }
    if (state.theme === 'peacock') {
      return {
        ...baseStyle,
        background: `linear-gradient(135deg, #134e4a 0%, #0f766e 100%)`
      };
    }
    if (state.theme === 'dark') {
      return {
        ...baseStyle,
        background: `linear-gradient(135deg, #111827 0%, #1f2937 100%)`
      };
    }
    return {
      ...baseStyle,
      background: `linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%)`
    };
  };

  const renderPage = () => {
    const { currentPage } = state;
    
    if (currentPage === 'home') return <HomePage />;
    if (currentPage === 'cart') return <CartPage />;
    if (currentPage === 'login') return <AuthPage />;
    if (currentPage === 'checkout') return <CheckoutPage />;
    if (currentPage === 'wishlist') return <WishlistPage />;
    if (currentPage === 'history') return <HistoryPage />;
    if (currentPage === 'orders') return <OrdersPage />;
    
    if (currentPage.startsWith('category-')) {
      const categoryId = currentPage.replace('category-', '');
      return <CategoryPage categoryId={categoryId} />;
    }
    
    if (currentPage.startsWith('product-')) {
      const productId = currentPage.replace('product-', '');
      return <ProductPage productId={productId} />;
    }

    if (currentPage.startsWith('search-')) {
      const query = currentPage.replace('search-', '');
      return <SearchPage query={query} />;
    }
    
    return <HomePage />;
  };

  return (
    <div style={getBackgroundStyle()}>
      {/* Dynamic CSS for accent color */}
      <style>
        {`
          .accent-bg {
            background-color: ${colorOptions[state.customColor].replace('bg-', '')} !important;
          }
          .accent-text {
            color: ${colorOptions[state.customColor].replace('bg-', '')} !important;
          }
          .accent-border {
            border-color: ${colorOptions[state.customColor].replace('bg-', '')} !important;
          }
        `}
      </style>
      
      <Header />
      <Navigation />
      <Sidebar />
      <main className="min-h-screen py-8">
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;